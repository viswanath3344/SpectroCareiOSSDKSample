//
//  SCDevicesTableViewCell.swift
//  SpectroBLETest
//
//  Created by Teja's MacBook on 26/04/19.
//  Copyright © 2019 Vedas labs. All rights reserved.
//

import UIKit

class SCDevicesTableViewCell: UITableViewCell {

    @IBOutlet weak var checkButton: UIButton!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
