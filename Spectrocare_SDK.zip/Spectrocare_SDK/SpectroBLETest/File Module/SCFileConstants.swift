//
//  SCFileConstants.swift
//  SpectroBLETest
//
//  Created by Ming-En Liu on 07/05/19.
//  Copyright © 2019 Vedas labs. All rights reserved.
//

import Foundation


enum JSonFileNames : String {
    case no5_3518_urineTest =  "no5_3518_urineTest"
}

//System Variables

let FETCH_FILES_URL_STRING = String(format: "http://54.210.61.0:8096/spectrocare/sdkjsonfiles/getallstripes")
let FETCH_FILES_DATA_STRING =  String(format: "http://54.210.61.0:8096/spectrocare/sdkjsonfiles/fileread")




