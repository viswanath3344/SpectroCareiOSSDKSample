//
//  BluetoothSDK.h
//  BluetoothSDK
//
//  Created by Teja's MacBook on 14/05/19.
//  Copyright © 2019 Vedas. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for BluetoothSDK.
FOUNDATION_EXPORT double BluetoothSDKVersionNumber;

//! Project version string for BluetoothSDK.
FOUNDATION_EXPORT const unsigned char BluetoothSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <BluetoothSDK/PublicHeader.h>


